# My First Repository

This is a **MarkDown** document , which is just a plain old document that uses certain character combinations to represenst formatting. Markdown documents can easily be converted to HTML documents. 

If you want to be effective as a software developerm there are 3 things that you need to strive to understand

1. Know your **problem** you are trying to solve.
2. Know they **langauge** in which you are creating the solution( C#, SQL, MD or C)
3. KNow the **tools** that you are you using to create your solution,.

## Useful Keybards Shortcuts
 - `[ctrl] + n` - Create a new file (works in most programs, including VS Code + VS2019 and MS WORD)
 - `[ctrl] + ` ` - Toggles the terminal/console window in the VS Code
 - `cls` - Does a clears screen in the terminal
 

 TODO.. Add more shorcuts for yourself.