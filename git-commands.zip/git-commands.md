# Git on the command line 

We cna use the git version control directly from the command line. Here are some useful cammands to get started

- `git status` - This will give you the the current status of your git repository

- `git add` - Use this commmand to "stage" all of your current changes sothat they are ready to be commited

- `git commit -m "Your Message"` -This command will take all of your staged changes and create a snapshot of the current state of your repository. Using commmits is how we generate a  **commit history**  for our repository

- `git pull` - Use this command to grab any changes from your remote repository (eg, GitHub) and pull them down to your local repository(the one on your computer)

- `git push` - This command will take whatever commits you have on your computer and push them to the remor repository on GitHub.com


There will be many other things to record as notes for shorcuts with git or version control

**TIP** Youshould make frequent , small commits when working on your projects.
